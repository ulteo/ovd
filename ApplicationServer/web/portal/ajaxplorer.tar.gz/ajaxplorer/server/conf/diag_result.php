<?php
$diag_result = array();
